
    <div class="col-xs-6 col-sm-2">
                        <a href="{{ route('social.redirect', ['provider' => 'google']) }}" class="btn btn-lg btn-block btn-danger omb_btn-google">
                                <i class="fa fa-google-plus visible-xs"></i>
                                <span class="hidden-xs">Google</span>
                        </a>
    </div>
    <div class="col-xs-6 col-sm-2">
                        <a href="{{ route('social.redirect', ['provider' => 'facebook']) }}" class="btn btn-lg btn-block btn-primary omb_btn-facebook">
                                <i class="fa fa-facebook visible-xs"></i>
                                <span class="hidden-xs">Facebook</span>
                        </a>
    </div>
    <div class="col-xs-6 col-sm-2">
                        <a href="{{ route('social.redirect', ['provider' => 'twitter']) }}" class="btn btn-lg btn-block btn-info omb_btn-twitter">
                                <i class="fa fa-twitter visible-xs"></i>
                                <span class="hidden-xs">Twitter</span>
                        </a>
    </div>
    <div class="col-xs-6 col-sm-2">
                        <a href="{{ route('social.redirect', ['provider' => 'github']) }}" class="btn btn-lg btn-block btn-success omb_btn-github">
                                <i class="fa fa-github visible-xs"></i>
                                <span class="hidden-xs">Github</span>
                        </a>
    </div>
