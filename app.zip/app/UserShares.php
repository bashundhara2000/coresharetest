<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserShares extends Model
{
    //
}
