<?php

namespace App\Providers;


/*-----------------------------------------------------------------------------
Structure to store the public key of users
-----------------------------------------------------------------------------*/
class publickey_Struct 
{
	public $pk_1 ;
	public $pk_2 ;
}
?>
