<?php

namespace App\Providers;

/*-----------------------------------------------------------------------------
Structure to store the private key and Public key of users
-----------------------------------------------------------------------------*/
class key_Struct 
{
	public $sk_1 ;
	public $sk_2 ;
	public $pk_1 ;
	public $pk_2 ;
}

?>
