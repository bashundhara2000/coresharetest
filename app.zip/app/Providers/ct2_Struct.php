<?php


namespace App\Providers;

/*-----------------------------------------------------------------------------
Structure to store second level Ciphertext (re-encryptable) 
-----------------------------------------------------------------------------*/
class ct2_Struct
{
        public $level=2;
        public $E1;
        public $F;
        public $V;
        public $W;
}
?>
