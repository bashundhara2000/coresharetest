<?php

namespace App\Providers;

/*-----------------------------------------------------------------------------
Structure to store the Re-encryption key of users
-----------------------------------------------------------------------------*/
class rekey_Struct 
{
	public $RKi_j;
	public $V;
	public $W;
}
?>
