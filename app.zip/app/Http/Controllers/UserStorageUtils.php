<?php

namespace App\Http\Controllers;

use App\Models\UserStorageAuth;
use App\Models\UserPreferences;
use Auth;
use DB;

class UserStorageUtils
{

	    public static function getUserPreffredStorage($userId) {
				
	    }

}
